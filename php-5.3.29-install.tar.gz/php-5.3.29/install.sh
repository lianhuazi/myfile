yum install -y libtool-ltdl-devel
yum install  -y libxml2-devel
yum install  -y  libjpeg-devel libpng-devel
yum install -y freetype-devel
yum install -y  libmcrypt-devel
yum install -y  mariadb-devel
ln -s /usr/lib64/mysql/libmysqlclient.so.18.0.0 /usr/lib/libmysqlclient.so

 ./configure   --prefix=/opt/php5.3   --enable-fpm   --with-fpm-user=www   --with-fpm-group=www   --with-gd  --enable-mbstring    --with-mcrypt --with-mysql --with-mysql-sock=/var/lib/mysql/mysql.sock  --with-zlib  --with-iconv   --with-jpeg-dir   --with-png-dir   --with-freetype-dir   --with-zlib-dir

